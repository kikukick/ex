// app.js (combined, updated)
// - Icon stream, sitemap, auth, cards, hero video checks, prefetch modules
// - Intro IDE typing/run/fade sequence (requires user to actually press Run)
// - Caret positioning fixed (pixel-based within .editor)
// - Visual-only in-page notification (no Notification API)
// - Exposes window.skipIntro() and window.triggerSecretRedirect()

const ICONS = [
    { name: 'Python', url: 'https://cdn.jsdelivr.net/npm/simple-icons@v11/icons/python.svg' },
    { name: 'C#', url: 'https://cdn.jsdelivr.net/npm/simple-icons@v11/icons/csharp.svg' },
    { name: 'HTML5', url: 'https://cdn.jsdelivr.net/npm/simple-icons@v11/icons/html5.svg' },
    { name: 'CSS3', url: 'https://cdn.jsdelivr.net/npm/simple-icons@v11/icons/css3.svg' },
    { name: 'JavaScript', url: 'https://cdn.jsdelivr.net/npm/simple-icons@v11/icons/javascript.svg' },
    { name: 'TypeScript', url: 'https://cdn.jsdelivr.net/npm/simple-icons@v11/icons/typescript.svg' },
    { name: 'Next.js', url: 'https://cdn.jsdelivr.net/npm/simple-icons@v11/icons/nextdotjs.svg' },
    { name: 'Node.js', url: 'https://cdn.jsdelivr.net/npm/simple-icons@v11/icons/nodedotjs.svg' }
  ];
  
  const MODULES = [
    'modules/ai-image.html',
    'modules/face-mask.html',
    'modules/light-ai-demo.html'
  ];
  
  const prefetchCache = new Map();
  const svgCache = new Map();
  
  // ---------- utilities ----------
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from((root || document).querySelectorAll(sel));
  const wait = ms => new Promise(r => setTimeout(r, ms));
  
  async function prefetchText(url) {
    if (prefetchCache.has(url)) return prefetchCache.get(url);
    try {
      const res = await fetch(url, { cache: 'no-cache' });
      if (!res.ok) throw new Error(`failed to fetch ${url}: ${res.status}`);
      const text = await res.text();
      prefetchCache.set(url, text);
      return text;
    } catch (err) {
      console.warn('prefetch error', url, err);
      return null;
    }
  }
  
  async function fetchSVG(url) {
    if (svgCache.has(url)) return svgCache.get(url);
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`SVG fetch failed (${res.status})`);
      const text = await res.text();
      svgCache.set(url, text);
      return text;
    } catch (e) {
      console.warn('SVG fetch failed', url, e);
      return null;
    }
  }
  
  function preloadLibraries() {
    const libs = [
      'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@3.20.0/dist/tf.min.js',
      'https://cdn.jsdelivr.net/npm/@tensorflow-models/body-pix@2.0.5/dist/body-pix.min.js'
    ];
    for (const src of libs) {
      const s = document.createElement('script');
      s.src = src;
      s.async = true;
      document.head.appendChild(s);
    }
  }
  
  // ---------- Icon stream ----------
  async function buildIconStream() {
    const container = document.getElementById('iconStream');
    if (!container) return;
    const iconsLoop = [...ICONS, ...ICONS];
    const unique = [...new Set(ICONS.map(i => i.url))];
    await Promise.all(unique.map(u => fetchSVG(u)));
    for (const it of iconsLoop) {
      const wrapper = document.createElement('div');
      wrapper.className = 'icon-item';
      const svgText = await fetchSVG(it.url);
      if (svgText) {
        const safeSvg = svgText.replace(/<\?xml.*?\?>/g, '').trim();
        wrapper.innerHTML = safeSvg;
        const svgEl = wrapper.querySelector('svg');
        if (svgEl) {
          svgEl.setAttribute('width', '54');
          svgEl.setAttribute('height', '54');
          svgEl.style.display = 'block';
        }
      } else {
        const img = document.createElement('img');
        img.alt = it.name;
        img.loading = 'lazy';
        img.src = it.url;
        wrapper.appendChild(img);
      }
      container.appendChild(wrapper);
    }
    const base = 18;
    container.style.animationDuration = `${Math.max(10, base * (iconsLoop.length / 8))}s`;
  }
  
document.addEventListener('DOMContentLoaded', () => {
  // Initialize users array in localStorage if it doesn't exist
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([]));
  }
  
  // Set current user from localStorage if exists
  let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
  
  // Elements
  const loginBtn = document.getElementById('loginBtn');
  const signupBtn = document.getElementById('signupBtn');
  const accountModal = document.getElementById('accountModal');
  const closeAccount = document.getElementById('closeAccount');
  const loginForm = document.getElementById('loginForm');
  const signupForm = document.getElementById('signupForm');
  const togglePasswordBtns = document.querySelectorAll('.toggle-password');
  
  // Toggle password visibility
  togglePasswordBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const input = this.previousElementSibling;
      const icon = this.querySelector('i');
      const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
      input.setAttribute('type', type);
      icon.classList.toggle('fa-eye');
      icon.classList.toggle('fa-eye-slash');
    });
  });
  
  // Show login form
  const showLoginForm = (e) => {
    if (e) e.preventDefault();
    // Hide signup form and show login form
    signupForm.style.display = 'none';
    loginForm.style.display = 'block';
    accountModal.classList.add('show');
    document.body.style.overflow = 'hidden';
  };
  
  // Show signup form
  const showSignupForm = (e) => {
    if (e) e.preventDefault();
    // Hide login form and show signup form
    loginForm.style.display = 'none';
    signupForm.style.display = 'block';
    accountModal.classList.add('show');
    document.body.style.overflow = 'hidden';
  };
  
  // Close modal and restore body scroll
  const closeModal = (e) => {
    if (e) e.preventDefault();
    if (accountModal) {
      accountModal.classList.remove('show');
      document.body.style.overflow = '';
    }
  };
  
  // Handle user registration
  const handleSignup = (e) => {
    e.preventDefault();
    
    const username = document.getElementById('signupUsername').value.trim();
    const password = document.getElementById('signupPassword').value.trim();
    
    // Simple validation
    if (!username || !password) {
      alert('ユーザー名とパスワードを入力してください');
      return;
    }
    
    // Check if user already exists
    const users = JSON.parse(localStorage.getItem('users')) || [];
    if (users.some(user => user.username === username)) {
      alert('このユーザー名は既に使用されています');
      return;
    }
    
    // Create new user
    const newUser = {
      id: Date.now().toString(),
      username,
      password, // In a real app, never store plain text passwords
      createdAt: new Date().toISOString()
    };
    
    // Save user
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    // Auto login
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    currentUser = newUser;
    
    // Close modal and refresh UI
    closeModal();
    alert('登録が完了しました！');
    window.location.href = 'edu-hack.html';
  };
  
  // Handle user login
  const handleLogin = (e) => {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    
    // Simple validation
    if (!username || !password) {
      alert('ユーザー名とパスワードを入力してください');
      return;
    }
    
    // Check credentials
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(u => u.username === username && u.password === password);
    
    if (user) {
      // Login successful
      localStorage.setItem('currentUser', JSON.stringify(user));
      currentUser = user;
      
      // Close modal and refresh UI
      closeModal();
      window.location.href = 'edu-hack.html';
    } else {
      alert('ユーザー名またはパスワードが正しくありません');
    }
  };
  
  // Event Listeners
  if (loginBtn) loginBtn.addEventListener('click', showLoginForm);
  if (signupBtn) signupBtn.addEventListener('click', showSignupForm);
  if (closeAccount) closeAccount.addEventListener('click', closeModal);
  if (loginForm) loginForm.addEventListener('submit', handleLogin);
  if (signupForm) signupForm.addEventListener('submit', handleSignup);
  
  // Close modal when clicking outside
  window.addEventListener('click', (e) => {
    if (e.target === accountModal || e.target.classList.contains('modal-overlay')) {
      closeModal(e);
    }
  });
  
  // Close with Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && accountModal && accountModal.classList.contains('show')) {
      closeModal();
    }
  });
  
  // If user is already logged in, redirect to edu-hack.html
  if (currentUser && window.location.pathname.endsWith('index.html')) {
    window.location.href = 'edu-hack.html';
  }
});      // Activate login tab and show login form
      const loginTab = document.querySelector('.tab-button[data-tab="login"]');
      const signupTab = document.querySelector('.tab-button[data-tab="signup"]');
      
      if (loginTab) loginTab.classList.add('active');
      if (signupTab) signupTab.classList.remove('active');
      if (loginForm) loginForm.classList.add('active');
      if (signupForm) signupForm.classList.remove('active');
    };
    
    // Show signup form
    const showSignupForm = (e) => {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      
      openModal();
      
      // Activate signup tab and show signup form
      const loginTab = document.querySelector('.tab-button[data-tab="login"]');
      const signupTab = document.querySelector('.tab-button[data-tab="signup"]');
      
      if (signupTab) signupTab.classList.add('active');
      if (loginTab) loginTab.classList.remove('active');
      if (signupForm) signupForm.classList.add('active');
      if (loginForm) loginForm.classList.remove('active');
    };
    
    // Close modal and restore body scroll
    const closeModal = (e) => {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      if (accountModal) {
        accountModal.classList.remove('show');
        // Add a small delay before re-enabling scroll to allow the modal transition to complete
        setTimeout(() => {
          document.body.style.overflow = '';
          document.body.style.paddingRight = ''; // Reset any padding added for scrollbar
        }, 300); // Match this with your CSS transition duration
      }
    };

    // Handle modal open to prevent body scroll
    const openModal = () => {
      if (accountModal) {
        // Save the current scroll position
        const scrollY = window.scrollY;
        document.body.style.position = 'fixed';
        document.body.style.width = '100%';
        document.body.style.top = `-${scrollY}px`;
        document.body.style.overflow = 'hidden';
        
        // Add padding to prevent layout shift when scrollbar disappears
        const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
        document.body.style.paddingRight = `${scrollbarWidth}px`;
        
        // Show modal
        accountModal.classList.add('show');
        
        // Restore scroll position when modal closes
        accountModal.addEventListener('transitionend', function restoreScroll() {
          if (!accountModal.classList.contains('show')) {
            const scrollY = document.body.style.top;
            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.width = '';
            window.scrollTo(0, parseInt(scrollY || '0') * -1);
            accountModal.removeEventListener('transitionend', restoreScroll);
          }
        }, { once: true });
      }
    };
  
    function refreshUI() {
      const cur = storage.getCurrent();
      if (cur && cur.username) {
        // Update UI for logged-in user
        if (loginBtn) loginBtn.style.display = 'none';
        if (signupBtn) signupBtn.style.display = 'none';
        
        // Show user info and logout button if they exist
        const userInfo = document.createElement('div');
        userInfo.className = 'user-info';
        userInfo.innerHTML = `
          <span class="username">${cur.username}</span>
          <button id="logoutBtn" class="btn btn-outline">
            <i class="fas fa-sign-out-alt"></i>
            <span>ログアウト</span>
          </button>
        `;
        
        const authNav = document.querySelector('.auth-nav');
        if (authNav) {
          authNav.innerHTML = '';
          authNav.appendChild(userInfo);
          
          // Add logout event listener
          const logoutBtn = document.getElementById('logoutBtn');
          if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
              e.preventDefault();
              storage.clearCurrent();
              window.location.reload();
            });
          }
        }
      } else {
        // Show login/signup buttons for non-logged in users
        if (loginBtn) loginBtn.style.display = 'flex';
        if (signupBtn) signupBtn.style.display = 'flex';
      }
    }
  
    // Toggle password visibility
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');
    togglePasswordButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        const input = button.previousElementSibling;
        const icon = button.querySelector('i');
        
        if (input.type === 'password') {
          input.type = 'text';
          icon.classList.remove('fa-eye');
          icon.classList.add('fa-eye-slash');
          button.setAttribute('aria-label', 'パスワードを非表示');
        } else {
          input.type = 'password';
          icon.classList.remove('fa-eye-slash');
          icon.classList.add('fa-eye');
          button.setAttribute('aria-label', 'パスワードを表示');
        }
      });
    });

    // Form Validation
    function validateEmail(email) {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(String(email).toLowerCase());
    }

    function validatePassword(password) {
      return password.length >= 8 && /[0-9]/.test(password) && /[a-zA-Z]/.test(password);
    }

    // Event Listeners
    if (loginBtn) loginBtn.addEventListener('click', showLoginForm);
    if (signupBtn) signupBtn.addEventListener('click', showSignupForm);
    if (closeAccount) closeAccount.addEventListener('click', closeModal);
    
    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
      if (e.target === accountModal || e.target.classList.contains('modal-overlay')) {
        closeModal(e);
      }
    });
    
    // Close with Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && accountModal.classList.contains('show')) {
        closeModal();
      }
    });
    
    // Tab switching
    tabButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        const tabId = button.getAttribute('data-tab');
        
        // Update active tab
        tabButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Show corresponding form
        if (tabId === 'login') {
          if (loginForm) loginForm.classList.add('active');
          if (signupForm) signupForm.classList.remove('active');
        } else {
          if (signupForm) signupForm.classList.add('active');
          if (loginForm) loginForm.classList.remove('active');
        }
      });
    });
    
    // Login form submission
    if (loginForm) {
      loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        const rememberMe = document.getElementById('remember-me')?.checked;
        
        // Validate email
        if (!validateEmail(email)) {
          showToast('有効なメールアドレスを入力してください', 'error');
          return;
        }
        
        // Validate password
        if (!password) {
          showToast('パスワードを入力してください', 'error');
          return;
        }
        
        // Show loading state
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ログイン中...';
        
        // Simulate API call
        setTimeout(() => {
          // Get users from localStorage
          const users = JSON.parse(localStorage.getItem('users') || '{}');
          
          // Find user by email
          const user = Object.values(users).find(u => u.email === email);
          
          if (user && user.password === password) {
            // Login successful
            storage.setCurrent({ 
              id: user.id, 
              username: user.username, 
              email: user.email 
            });
            
            if (rememberMe) {
              localStorage.setItem('rememberMe', 'true');
            } else {
              localStorage.removeItem('rememberMe');
            }
            
            closeModal();
            refreshUI();
            showToast('ログインに成功しました', 'success');
          } else {
            // Login failed
            showToast('メールアドレスまたはパスワードが正しくありません', 'error');
          }
          
          // Reset button state
          submitBtn.disabled = false;
          submitBtn.innerHTML = originalBtnText;
        }, 800);
      });
    }
    
    // Signup form submission
    if (signupForm) {
      signupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const username = document.getElementById('signup-username').value.trim();
        const email = document.getElementById('signup-email').value.trim();
        const password = document.getElementById('signup-password').value;
        const confirmPassword = document.getElementById('signup-confirm-password').value;
        const termsAgree = document.getElementById('terms-agree').checked;
        
        // Validate username
        if (username.length < 3) {
          showToast('ユーザー名は3文字以上で入力してください', 'error');
          return;
        }
        
        // Validate email
        if (!validateEmail(email)) {
          showToast('有効なメールアドレスを入力してください', 'error');
          return;
        }
        
        // Validate password
        if (!validatePassword(password)) {
          showToast('パスワードは8文字以上で、英数字を含む必要があります', 'error');
          return;
        }
        
        if (password !== confirmPassword) {
          showToast('パスワードが一致しません', 'error');
          return;
        }
        
        // Check terms agreement
        if (!termsAgree) {
          showToast('利用規約に同意する必要があります', 'error');
          return;
        }
        
        // Show loading state
        const submitBtn = signupForm.querySelector('button[type="submit"]');
        const originalBtnText = submitBtn.innerHTML;
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> アカウントを作成中...';
        
        // Simulate API call
        setTimeout(() => {
          // Get existing users
          const users = JSON.parse(localStorage.getItem('users') || '{}');
          
          // Check if email already exists
          if (Object.values(users).some(user => user.email === email)) {
            showToast('このメールアドレスは既に使用されています', 'error');
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
            return;
          }
          
          // Create new user
          const userId = 'user_' + Date.now();
          users[userId] = {
            id: userId,
            username,
            email,
            password, // In a real app, hash the password!
            createdAt: new Date().toISOString()
          };
          
          try {
            // Save to localStorage
            localStorage.setItem('users', JSON.stringify(users));
            
            // Auto-login
            storage.setCurrent({ 
              id: userId, 
              username, 
              email 
            });
            
            // Reset form
            signupForm.reset();
            
            // Switch to login tab
            const loginTab = document.querySelector('.tab-button[data-tab="login"]');
            if (loginTab) loginTab.click();
            
            closeModal();
            refreshUI();
            showToast('アカウントが作成されました', 'success');
          } catch (error) {
            console.error('Error saving user:', error);
            showToast('エラーが発生しました。もう一度お試しください。', 'error');
          } finally {
            // Reset button state
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalBtnText;
          }
        }, 1000);
      });
    }
    
    // Initialize UI
    refreshUI();
    
    // Add click outside to close
    if (accountModal) {
      accountModal.addEventListener('click', (e) => {
        if (e.target === accountModal) {
          closeModal();
        }
      });
    }
    
    // Add logout button click handler if it exists
    const logoutBtnEl = document.getElementById('logoutBtn');
    if (logoutBtnEl) {
      logoutBtnEl.addEventListener('click', (e) => {
        e.preventDefault();
        storage.clearCurrent();
        window.location.reload();
      });
    }
  }
  
  // Show toast notification
  function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
      toastContainer = document.createElement('div');
      toastContainer.className = 'toast-container';
      document.body.appendChild(toastContainer);
    }
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    // Add icon based on type
    let icon = 'info-circle';
    if (type === 'success') icon = 'check-circle';
    if (type === 'error') icon = 'exclamation-circle';
    if (type === 'warning') icon = 'exclamation-triangle';
    
    toast.innerHTML = `
      <div class="toast-icon">
        <i class="fas fa-${icon}"></i>
      </div>
      <div class="toast-message">${message}</div>
      <button class="toast-close" aria-label="閉じる">
        <i class="fas fa-times"></i>
      </button>
    `;
    
    toastContainer.appendChild(toast);
    
    // Trigger reflow
    void toast.offsetWidth;
    
    // Show toast with animation
    toast.classList.add('show');
    
    // Auto-remove toast after delay
    const autoRemove = setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => {
        if (toast.parentNode === toastContainer) {
          toastContainer.removeChild(toast);
        }
        // Remove container if empty
        if (toastContainer.children.length === 0) {
          document.body.removeChild(toastContainer);
        }
      }, 300);
    }, 5000);
    
    // Close button
    const closeBtn = toast.querySelector('.toast-close');
    closeBtn.addEventListener('click', () => {
      clearTimeout(autoRemove);
      toast.classList.remove('show');
      setTimeout(() => {
        if (toast.parentNode === toastContainer) {
          toastContainer.removeChild(toast);
        }
        if (toastContainer.children.length === 0) {
          document.body.removeChild(toastContainer);
        }
      }, 300);
    });
    
    // Pause auto-remove on hover
    toast.addEventListener('mouseenter', () => {
      clearTimeout(autoRemove);
    });
    
    toast.addEventListener('mouseleave', () => {
      const newAutoRemove = setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
          if (toast.parentNode === toastContainer) {
            toastContainer.removeChild(toast);
          }
          if (toastContainer.children.length === 0) {
            document.body.removeChild(toastContainer);
          }
        }, 300);
      }, 2000);
      
      // Store the new timeout ID on the toast element
      toast._autoRemove = newAutoRemove;
    });
  }
  
  // ---------- Site Map + Scrollspy ----------
  function buildSiteMap() {
    const map = [
      { id: 'intro', label: 'Interactive Demos — Overview' },
      { id: 'face-mask-card', label: 'Interactive Demos — 顔認識 + マスク' },
      { id: 'ai-image-card', label: 'Interactive Demos — AI 画像生成' },
      { id: 'light-ai-card', label: 'Interactive Demos — 軽量AIデモ' },
      { id: 'about', label: 'About / 自分について' }
    ];
    const ul = document.getElementById('siteMap');
    if (!ul) return;
    ul.innerHTML = '';
    const linkMap = {};
  
    for (const item of map) {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = `#${item.id}`;
      a.textContent = item.label;
      a.dataset.target = item.id;
      a.addEventListener('click', (e) => {
        e.preventDefault();
        const target = document.getElementById(item.id);
        if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
      li.appendChild(a);
      ul.appendChild(li);
      linkMap[item.id] = a;
    }
  
    const sections = map.map(m => document.getElementById(m.id)).filter(Boolean);
    if (sections.length === 0) return;
  
    const observer = new IntersectionObserver((entries) => {
      entries.sort((a, b) => b.intersectionRatio - a.intersectionRatio);
      const best = entries[0];
      if (!best) return;
      const id = best.target.id;
      if (best.intersectionRatio > 0.05) {
        document.querySelectorAll('#siteMap a').forEach(a => a.classList.remove('active'));
        const link = linkMap[id];
        if (link) link.classList.add('active');
      }
    }, { root: null, rootMargin: '0px 0px -40% 0px', threshold: [0, 0.05, 0.2, 0.5, 1.0] });
  
    sections.forEach(s => observer.observe(s));
  }
  
  // ---------- Cards & iframe embed ----------
  function initCards() {
    const cards = document.querySelectorAll('.card[data-module]');
    const embedModal = document.getElementById('embedModal');
    const embedInner = document.getElementById('embedInner');
    const closeEmbed = document.getElementById('closeEmbed');
  
    if (!cards) return;
  
    async function openModule(url) {
      embedInner.innerHTML = '';
      const html = await prefetchText(url);
      const iframe = document.createElement('iframe');
      iframe.style.width = '100%';
      iframe.style.height = '100%';
      iframe.style.border = '0';
      iframe.loading = 'eager';
      iframe.sandbox = 'allow-scripts allow-same-origin allow-forms allow-modals';
      if (html) {
        iframe.srcdoc = html;
        embedInner.appendChild(iframe);
        embedModal.classList.add('active');
        embedModal.setAttribute('aria-hidden', 'false');
      } else {
        iframe.src = url;
        embedInner.appendChild(iframe);
        embedModal.classList.add('active');
        embedModal.setAttribute('aria-hidden', 'false');
      }
    }
  
    cards.forEach(card => {
      card.addEventListener('click', () => {
        const url = card.dataset.module;
        if (!url) return;
        openModule(url);
      });
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          card.click();
        }
      });
    });
  
    if (closeEmbed) {
      closeEmbed.addEventListener('click', () => {
        embedInner.innerHTML = '';
        embedModal.classList.remove('active');
        embedModal.setAttribute('aria-hidden', 'true');
      });
    }
  
    if (embedModal) {
      embedModal.addEventListener('click', (e) => {
        if (e.target === embedModal) {
          embedInner.innerHTML = '';
          embedModal.classList.remove('active');
          embedModal.setAttribute('aria-hidden', 'true');
        }
      });
    }
  }
  
  // ---------- Prefetch modules ----------
  async function prefetchAllModules() {
    for (const m of MODULES) {
      prefetchText(m);
    }
  }
  
  // ---------- Hero Video check ----------
  async function ensureHeroVideo() {
    const wrap = document.getElementById('topVideoWrap');
    const vid = document.getElementById('heroVideo');
    const fallback = document.getElementById('videoFallback');
    const stateLabel = document.getElementById('videoStateLabel');
    const errorMsg = document.getElementById('videoErrorMsg');
  
    if (!vid || !wrap) return;
  
    if (stateLabel) stateLabel.textContent = 'Initializing video...';
    if (errorMsg) errorMsg.textContent = '';
  
    function showFallback(msg) {
      console.warn('Hero video fallback:', msg);
      if (fallback) fallback.style.display = 'flex';
      wrap.classList.remove('playing');
      wrap.classList.add('no-video');
      if (stateLabel) stateLabel.textContent = 'Video unavailable';
      if (errorMsg) errorMsg.textContent = msg;
    }
  
    try {
      const playPromise = vid.play();
      if (playPromise !== undefined) {
        await playPromise;
      }
    } catch (err) {
      const msg = (err && err.message) ? err.message : String(err);
      showFallback(`play() failed: ${msg}`);
    }
  
    const metaPromise = new Promise((resolve) => {
      let resolved = false;
      function onMeta() {
        if (resolved) return;
        resolved = true;
        resolve(true);
      }
      vid.addEventListener('loadedmetadata', onMeta, { once: true });
      vid.addEventListener('loadeddata', onMeta, { once: true });
      setTimeout(() => { if (!resolved) { resolved = true; resolve(false); } }, 2500);
    });
  
    const metaLoaded = await metaPromise;
  
    const rect = vid.getBoundingClientRect();
    const vw = vid.videoWidth || rect.width;
    const vh = vid.videoHeight || rect.height;
    if (!(vw > 10 && vh > 10)) {
      let resolvedPlay = false;
      const playWait = new Promise((resolve) => {
        function onPlaying() {
          if (resolvedPlay) return;
          resolvedPlay = true;
          resolve(true);
        }
        vid.addEventListener('playing', onPlaying, { once: true });
        setTimeout(() => { if (!resolvedPlay) { resolvedPlay = true; resolve(false); } }, 2000);
      });
      const played = await playWait;
      const vw2 = vid.videoWidth || vid.getBoundingClientRect().width;
      const vh2 = vid.videoHeight || vid.getBoundingClientRect().height;
      if (!(vw2 > 10 && vh2 > 10)) {
        showFallback('video element has near-zero size after wait; check CSS/container or source.');
        console.warn('video sizes', { vw, vh, vw2, vh2, rect });
        return;
      }
    }
  
    wrap.classList.add('playing');
    wrap.classList.remove('no-video');
    if (fallback) fallback.style.display = 'none';
    if (stateLabel) stateLabel.textContent = 'Playing';
    console.log('Hero video is playing (verified)');
    vid.addEventListener('error', (e) => {
      const code = vid.error ? vid.error.code : 'unknown';
      const detail = vid.error && vid.error.message ? vid.error.message : JSON.stringify(e);
      showFallback(`Video error (code ${code}): ${detail}`);
      console.error('Video element error', e, vid.error);
    });
  }
  
  // ---------- Intro IDE typing/run/fade (wait for user click) ----------
  
  const INTRO_CONFIG = {
    typingSpeedMs: 60,
    postTypeDelay: 180,
    runPressDuration: 420,
    outputShowDelay: 120,
    splashFadeDelay: 700,
    splashFadeDuration: 900,
    notificationDelay: 250,
    fakeNoticeDuration: 6000
  };
  
  let _waitingForRun = null; // {resolve, reject, handler} while waiting for user click
  
  window.skipIntro = function () {
    try {
      _skipIntroImmediate();
    } catch (e) {
      console.warn('skipIntro failed', e);
    }
  };
  
  async function initIntroTyping() {
    const splash = document.getElementById('ideSplash');
    if (!splash) return;
  
    const typedEl = splash.querySelector('.typed');
    const caretEl = splash.querySelector('.caret');
    const runBtn = splash.querySelector('#introRunBtn') || splash.querySelector('.run-btn');
    const outputEl = splash.querySelector('#introOutput');
    const fakeNotice = splash.querySelector('#fakeNotification');
    const blocker = splash.querySelector('.splash-blocker');
  
    if (!typedEl || !caretEl || !runBtn || !outputEl) {
      console.warn('Intro elements missing (typed/caret/run/output) — skipping JS intro (CSS fallback may run).');
      return;
    }
  
    // remove CSS auto-run so JS controls it
    splash.classList.remove('typing-run');
  
    // block pointer while typing/waiting
    if (blocker) blocker.style.pointerEvents = 'all';
  
    // prepare typed text
    const fullText = typedEl.textContent.trim();
    typedEl.textContent = '';
    typedEl.style.width = 'auto';
    typedEl.setAttribute('aria-hidden', 'false');
  
    // reset terminal output
    outputEl.textContent = '';
    outputEl.setAttribute('aria-hidden', 'true');
  
    // hide fake notice initially
    if (fakeNotice) {
      fakeNotice.style.transition = 'opacity .3s ease, transform .3s ease';
      fakeNotice.style.opacity = '0';
      fakeNotice.style.transform = 'translateY(-10px) scale(.98)';
      fakeNotice.style.pointerEvents = 'none';
    }
  
    try {
      // 1) type
      await typeTextWithCaret(typedEl, caretEl, fullText, INTRO_CONFIG.typingSpeedMs);
  
      // 2) after typing, wait a short time then wait for actual user click on Run
      await wait(INTRO_CONFIG.postTypeDelay);
  
      // Provide a small visual hint (animate run button subtly)
      animateAttentionRunBtn(runBtn);
  
      // Wait for user's click (or Enter key when focused). If user doesn't click, intro waits.
      await waitForUserRun(runBtn);
  
      // When clicked, play press animation (but don't dispatch another click)
      await animateRunPress(runBtn, INTRO_CONFIG.runPressDuration, { simulateClick: false });
  
      // 3) show terminal output
      await wait(INTRO_CONFIG.outputShowDelay);
      showTerminalOutputJS(outputEl, 'Hello World!');
  
      // 4) fade out splash
      await wait(INTRO_CONFIG.splashFadeDelay);
      await fadeOutSplashJS(splash, INTRO_CONFIG.splashFadeDuration);
  
      // 5) show fake notice
      await wait(INTRO_CONFIG.notificationDelay);
      showFakeNoticeJS(fakeNotice, 'Hello World!', 'kiku_demo.py executed');
  
      // ensure hero video running
      ensureHeroVideo();
  
    } catch (err) {
      console.error('Intro typing error', err);
      _skipIntroImmediate();
    }
  }
  
  // accurate caret placement: position caret pixel-perfect inside .editor
  async function typeTextWithCaret(typedEl, caretEl, text, speedMs) {
    if (!text) return;
    typedEl.style.whiteSpace = 'pre';
    typedEl.style.overflow = 'hidden';
  
    // Ensure caret is absolutely positioned inside .editor
    const editor = typedEl.closest('.editor');
    if (!editor) return;
  
    caretEl.style.position = 'absolute';
    caretEl.style.display = 'block';
    caretEl.style.transform = 'none';
    caretEl.style.zIndex = 5;
    caretEl.style.transition = 'none';
    caretEl.style.willChange = 'left, top';
  
    // Compute vertical alignment baseline offsets
    const editorStyle = window.getComputedStyle(editor);
    const editorPaddingTop = parseFloat(editorStyle.paddingTop || 0);
  
    let out = '';
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      out += ch;
      typedEl.textContent = out;
  
      // measure text width inside editor to position caret
      // typedEl.offsetLeft + typedEl.clientWidth gives pixel position relative to editor
      const caretLeft = typedEl.offsetLeft + typedEl.clientWidth;
      // top aligned to typedEl top
      const caretTop = typedEl.offsetTop + editorPaddingTop;
  
      caretEl.style.left = `${caretLeft}px`;
      // set top to vertically center (small tweak)
      caretEl.style.top = `${typedEl.offsetTop}px`;
  
      // set caret height to match font-size / line-height
      const lineHeight = parseFloat(window.getComputedStyle(typedEl).lineHeight) || 18;
      caretEl.style.height = `${lineHeight}px`;
  
      // small human variance in typing speed
      const variance = Math.random() * 0.6 - 0.3;
      const delay = Math.max(12, Math.round(speedMs + variance * 18));
      await wait(delay);
    }
    // final pause
    await wait(120);
  }
  
  // animate run button to draw user's attention (subtle pulse)
  function animateAttentionRunBtn(btn) {
    try {
      if (!btn) return;
      // Using WAAPI if available
      if (btn.animate) {
        const anim = btn.animate([
          { transform: 'scale(1)', boxShadow: '0 10px 30px rgba(42,103,255,0.24)' },
          { transform: 'scale(1.03)', boxShadow: '0 18px 40px rgba(42,103,255,0.28)' },
          { transform: 'scale(1)', boxShadow: '0 10px 30px rgba(42,103,255,0.24)' }
        ], { duration: 1100, iterations: 2, easing: 'ease-in-out' });
        // no need to store animation; user click ends waitForUser
      } else {
        btn.classList.add('pulse'); // fallback (CSS class may not exist)
        setTimeout(() => btn.classList.remove('pulse'), 2200);
      }
    } catch (e) { /* ignore */ }
  }
  
  // wait for the user to press Run (click or keyboard)
  function waitForUserRun(btn) {
    return new Promise((resolve, reject) => {
      if (!btn) return resolve();
  
      // handler for Runボタンクリック
      const onClick = () => {
        cleanup();
        resolve();
      };
  
      // handler for キー入力
      // Enter はグローバルに受け付ける
      // Space はボタンにフォーカスがある時のみ受け付ける
      const onKey = (e) => {
        if (e.key === 'Enter' || (e.key === ' ' && document.activeElement === btn)) {
          cleanup();
          resolve();
        }
      };
  
      // skipIntro() 呼び出し時の監視
      const onSkipWatch = () => {
        cleanup();
        resolve();
      };
  
      function cleanup() {
        btn.removeEventListener('click', onClick);
        document.removeEventListener('keydown', onKey);
        document.removeEventListener('skipIntroCalled', onSkipWatch);
        _waitingForRun = null;
      }
  
      // store for skipIntro immediate cancel
      _waitingForRun = { resolve, reject, cleanup };
  
      // イベント登録
      btn.addEventListener('click', onClick, { once: true });
      document.addEventListener('keydown', onKey); // ← フォールバックとして全体にEnterキーを監視
      document.addEventListener('skipIntroCalled', onSkipWatch);
  
      // アクセシビリティのためRunボタンをフォーカス
      try {
        btn.tabIndex = 0;
        btn.focus({ preventScroll: true });
      } catch (e) {
        btn.focus();
      }
    });
  }
  
  // animate run press: if simulateClick=true will dispatch a click during animation; otherwise just animate
  function animateRunPress(btn, duration, options = { simulateClick: true }) {
    return new Promise((resolve) => {
      try {
        if (btn.animate) {
          const anim = btn.animate([
            { transform: 'scale(1)', offset: 0 },
            { transform: 'scale(0.92)', offset: 0.45 },
            { transform: 'scale(1)', offset: 1 }
          ], {
            duration: duration,
            easing: 'cubic-bezier(.2,.8,.2,1)'
          });
          if (options.simulateClick) {
            setTimeout(() => { safeDispatchClick(btn); }, Math.round(duration * 0.45));
          }
          anim.onfinish = () => resolve();
        } else {
          // fallback class toggle
          btn.classList.add('pressed');
          if (options.simulateClick) safeDispatchClick(btn);
          setTimeout(() => { btn.classList.remove('pressed'); resolve(); }, duration);
        }
      } catch (e) {
        if (options.simulateClick) safeDispatchClick(btn);
        setTimeout(resolve, duration);
      }
    });
  }
  
  function safeDispatchClick(btn) {
    try {
      btn.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      if (typeof btn.click === 'function') btn.click();
    } catch (e) { /* ignore */ }
  }
  
  function showTerminalOutputJS(outputEl, text) {
    try {
      outputEl.setAttribute('aria-hidden', 'false');
      outputEl.textContent = text;
      outputEl.style.opacity = '0';
      outputEl.style.transform = 'translateY(6px)';
      outputEl.style.transition = 'opacity .35s ease, transform .35s ease';
      void outputEl.offsetHeight;
      outputEl.style.opacity = '1';
      outputEl.style.transform = 'translateY(0)';
    } catch (e) {
      console.warn('showTerminalOutputJS error', e);
    }
  }
  
  function fadeOutSplashJS(splashEl, durationMs) {
    return new Promise((resolve) => {
      try {
        let done = false;
        const onTransEnd = (ev) => {
          if (ev && ev.target !== splashEl) return;
          if (done) return;
          done = true;
          splashEl.removeEventListener('transitionend', onTransEnd);
          finalizeRemove();
        };
        splashEl.addEventListener('transitionend', onTransEnd);
        splashEl.classList.add('fading');
        setTimeout(() => {
          if (!done) {
            done = true;
            splashEl.removeEventListener('transitionend', onTransEnd);
            finalizeRemove();
          }
        }, durationMs + 200);
  
        function finalizeRemove() {
          try {
            splashEl.style.display = 'none';
            splashEl.setAttribute('aria-hidden', 'true');
            const blocker = splashEl.querySelector('.splash-blocker');
            if (blocker) blocker.style.pointerEvents = 'none';
            const main = document.getElementById('mainContent') || document.body;
            if (main && typeof main.focus === 'function') {
              try { main.focus({ preventScroll: true }); } catch (e) { main.focus(); }
            }
          } catch (e) {}
          resolve();
        }
      } catch (err) {
        console.warn('fadeOutSplashJS failed', err);
        try { splashEl.style.display = 'none'; splashEl.setAttribute('aria-hidden', 'true'); } catch (e) {}
        resolve();
      }
    });
  }
  
  // show visual-only fake notice
  function showFakeNoticeJS(fakeNoticeEl, title, body) {
    if (!fakeNoticeEl) {
      const el = document.createElement('div');
      el.textContent = title || body || 'Hello';
      el.style.position = 'fixed';
      el.style.top = '18px';
      el.style.right = '18px';
      el.style.padding = '10px 12px';
      el.style.background = '#ffffff';
      el.style.color = '#000';
      el.style.borderRadius = '8px';
      el.style.boxShadow = '0 8px 30px rgba(0,0,0,0.35)';
      el.style.zIndex = 20000;
      document.body.appendChild(el);
      setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .45s ease'; }, 2500);
      setTimeout(() => { try { el.remove(); } catch (e) {} }, 3500);
      return;
    }
    try {
      const strong = fakeNoticeEl.querySelector('strong');
      const sub = fakeNoticeEl.querySelector('.notice-sub');
      if (strong) strong.textContent = title || 'Notification';
      if (sub) sub.textContent = body || '';
    } catch (e) {}
    fakeNoticeEl.style.opacity = '0';
    fakeNoticeEl.style.transform = 'translateY(-10px) scale(.98)';
    fakeNoticeEl.style.pointerEvents = 'none';
    requestAnimationFrame(() => {
      fakeNoticeEl.style.transition = 'opacity .3s ease, transform .3s ease';
      fakeNoticeEl.style.opacity = '1';
      fakeNoticeEl.style.transform = 'translateY(0) scale(1)';
      fakeNoticeEl.style.pointerEvents = 'auto';
    });
    setTimeout(() => {
      try {
        fakeNoticeEl.style.opacity = '0';
        fakeNoticeEl.style.transform = 'translateY(-8px) scale(.98)';
        fakeNoticeEl.style.pointerEvents = 'none';
      } catch (e) {}
    }, INTRO_CONFIG.fakeNoticeDuration);
  }
  
  // immediate skip fallback used by window.skipIntro()
  function _skipIntroImmediate() {
    const splash = document.getElementById('ideSplash');
    if (!splash) return;
    const blocker = splash.querySelector('.splash-blocker');
    if (blocker) blocker.style.pointerEvents = 'none';
    const outputEl = splash.querySelector('#introOutput');
    if (outputEl) {
      outputEl.setAttribute('aria-hidden', 'false');
      outputEl.textContent = 'Hello World!';
    }
    try { splash.style.transition = 'none'; splash.style.opacity = '0'; splash.style.display = 'none'; splash.setAttribute('aria-hidden', 'true'); } catch (e) {}
    // cancel waiting for run button if any
    if (_waitingForRun && typeof _waitingForRun.cleanup === 'function') {
      try { _waitingForRun.cleanup(); } catch (e) {}
      _waitingForRun = null;
    }
    const fakeNotice = splash.querySelector('#fakeNotification');
    setTimeout(() => showFakeNoticeJS(fakeNotice, 'Hello World!', 'kiku_demo.py executed'), 200);
    // broadcast skip event for any listeners
    document.dispatchEvent(new Event('skipIntroCalled'));
  }
  
  // ---------- Console-exposed redirect ----------
  window.triggerSecretRedirect = function () {
    window.location.href = 'https://example.com';
  };
  
  // ---------- Bootstrap ----------
  document.addEventListener('DOMContentLoaded', async () => {
    // Initialize authentication UI
    initAuthUI();
    
    // Start the intro typing sequence (if intro exists)
    initIntroTyping();
  
    // Meanwhile build other UI
    await buildIconStream();
    buildSiteMap();
    initCards();
    preloadLibraries();
    await prefetchAllModules();
  
    console.log('App initialized: icons, sitemap, auth, cards initialized. Intro started (if available).');
  });
